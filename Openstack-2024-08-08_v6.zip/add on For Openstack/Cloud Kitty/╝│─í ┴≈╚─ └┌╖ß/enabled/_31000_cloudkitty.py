FEATURE = 'cloudkitty'

ADD_ANGULAR_MODULES = [
    'horizon.dashboard.cloudkitty',
]
AUTO_DISCOVER_STATIC_FILES = True
